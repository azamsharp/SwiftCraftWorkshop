//
//  ContentView.swift
//  Carvana
//
//  Created by Mohammad Azam on 6/5/23.
//

import SwiftUI
import CoreML

struct Car: Identifiable {
    let id: Double
    let name: String
}

extension Locale {
    
    static var currencyCode: String {
        current.currency?.identifier ?? "USD"
    }
}

struct ContentView: View {
    
    @State private var year: Double = 2021
    @State private var selectedName: String = "Toyota Corolla"
    @State private var selectedCarId: Double?
    @State private var miles: Double?
    
    @State private var price: Double?
    
    let model = try! CarvanaModel(configuration: MLModelConfiguration())
    
    let calendar = Calendar.current
    
    private var last5Years: ClosedRange<Int> {
        let currentYear = calendar.component(.year, from: Date())
        return (currentYear - 5)...currentYear
    }
    
    private var cars: [Car] {
        
        guard let fileURL = Bundle.main.url(forResource: "CarNames2", withExtension: "json") else {
            fatalError("Failed to load JSON file in bundle.")
        }
        
        do {
            let jsonData = try Data(contentsOf: fileURL)
            let decodedCarDictionaries = try JSONDecoder().decode([String: Int].self, from: jsonData)
           
            return decodedCarDictionaries.keys.map { key in
                let value = decodedCarDictionaries[key] ?? 0
                return Car(id: Double(value), name: key)
            }
            
        } catch {
            return []
        }
        
    }
    
    
    private var isFormValid: Bool {
        miles != nil && miles! > 0
    }
    
    var body: some View {
        Form {
            
            Picker("Select Name", selection: $selectedCarId) {
                ForEach(cars) { car in
                    Text(car.name).tag(Optional(car.id))
                }
            }
            
            TextField("Year", value: $year, formatter: NumberFormatter())
            TextField("Miles", value: $miles, format: .number)
            
            Button {
                                
                // action
                do {
                    
                    let results = try model.prediction(Year: year, Miles: miles!, LabelEncodedName: selectedCarId ?? 0.0)
                    
                    price = results.Price
                } catch {
                    print(error.localizedDescription)
                }
                
            } label: {
                Text("Predict Car Price")
                    .frame(maxWidth: .infinity, alignment: .center)
            }.buttonStyle(.borderedProminent)
            .disabled(!isFormValid)

            if let price {
                if price > 0 {
                    Text(price, format: .currency(code: Locale.currencyCode))
                        .font(.title)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .foregroundColor(.green)
                } else {
                    Text("N/A")
                        .font(.title)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .foregroundColor(.green)
                }
            }
            
            
        }.navigationTitle("Carvana")
           
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ContentView()
        }
    }
}
