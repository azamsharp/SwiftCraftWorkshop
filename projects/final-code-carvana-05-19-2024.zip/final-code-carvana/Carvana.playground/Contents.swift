import Cocoa
import CreateML
import TabularData
import CreateMLComponents

let url = Bundle.main.url(forResource: "data", withExtension: "csv")!
var dataFrame = try DataFrame(contentsOfCSVFile: url)

let filterByYearsSlice = dataFrame.filter(on: "Year", Int.self) { value in
    guard let value = value else { return false }
    return value <= 2025
}

dataFrame = DataFrame(filterByYearsSlice)

// carNames is AnyColumnSlice
// How can I get carNames as an [String]
let carNames: [String] = dataFrame["Name"].distinct().map { $0 as! String}
var nameToLabelMap = [String: Int]()

for (index, name) in carNames.enumerated() {
    nameToLabelMap[name.trimmingCharacters(in: .whitespacesAndNewlines)] = index + 1
}

dataFrame["LabelEncodedName"] = dataFrame["Name"].map { name in
    guard let label = nameToLabelMap[name as! String] else {
        return 0 // Default label if name not found
    }
    return label
}

// remove the Name column
//dataFrame.removeColumn("Name")

dataFrame.removeColumn("Year")
dataFrame.removeColumn("Miles")
dataFrame.removeColumn("Price")


print(nameToLabelMap)

let fileURL = URL(fileURLWithPath: "/Users/azamsharp/Desktop/CarNames.json")

let jsonData = try JSONSerialization.data(withJSONObject: nameToLabelMap, options: .prettyPrinted)
    
    // Write the JSON data to the file
try jsonData.write(to: fileURL)

/*
let regressor = try MLRegressor(trainingData: dataFrame, targetColumn: "Price")

let metaData = MLModelMetadata(author: "Mohammad Azam", shortDescription: "Carvana Model", license: nil, version: "1.0", additional: nil)

try regressor.write(toFile: "/Users/azamsharp/Desktop/Carvana.mlmodel", metadata: metaData)
*/
