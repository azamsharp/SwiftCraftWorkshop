//
//  HelloCoreMLApp.swift
//  HelloCoreML
//
//  Created by Mohammad Azam on 5/19/23.
//

import SwiftUI

@main
struct HelloCoreMLApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
